import React from 'react'

function Revalidacion_extranjeros() {
  return (
    <div>Realidacion a Extranjeros</div>
  )
}

export default Revalidacion_extranjeros