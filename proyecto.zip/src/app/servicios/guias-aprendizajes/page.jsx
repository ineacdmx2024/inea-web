import React from 'react'

function Guias_aprendizajes() {
  return (
    <div>Guias de aprendizajes</div>
  )
}

export default Guias_aprendizajes