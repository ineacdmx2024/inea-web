import React from 'react'

function Constancia_Comipems() {
  return (
    <div>Constancia COMIPEMS</div>
  )
}

export default Constancia_Comipems