import React from 'react'

function DescargarModulos() {
  return (
    <div>Descargar Modulos</div>
  )
}

export default DescargarModulos