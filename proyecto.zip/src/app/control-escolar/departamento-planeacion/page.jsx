import React from "react";

function DepartamentoPlaneacion() {
  return (
    <div>Departamento de planeacion, seguimiento operativo y acreditacion</div>
  );
}

export default DepartamentoPlaneacion;
